ML.NET is a cross-platform open-source machine learning framework which makes machine learning accessible to .NET developers.

For more information, see the [ML.NET documentation](https://docs.microsoft.com/dotnet/machine-learning/).