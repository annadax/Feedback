feedbackdata.rar includes 2 part:

feedbacks.txt is total feedbacks with 	label 0 and 1 respectively. 

0 illustrates the negative point of view
1 illustrates the positive point of view

All labels perform our team opinions, not represent for all ideas.
------
In the project, please replace my text file path to your text file path in order to make sure the project run correctly.
------
While running the frmShowFeedbacks, please click confirm 2 times separately as the first time just to show the feedback and the second time is save the model into combobox. 

Then click the OK button to view the percentage point of view.
------
This project is just 1.0 version as we are shortage of time, however, if there is any request to enhance, we are willing to work.
------
Video demo link: https://drive.google.com/file/d/1aZo3MgE1pgaiwpNNt7-viXQKKLDfOZgA/view?usp=sharing
------
Thanks for your reading!!!
